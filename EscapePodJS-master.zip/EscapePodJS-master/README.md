# EscapePodJS 

AngularJS version of [Escape Pod](https://github.com/tsasioglu/Escape-Pod) podcast downloader.

![screenshot](img/screenshot.png)
