import tensorflow as tf
import json
import numpy as np
import os
from tqdm import tqdm
from util import get_record_parser, get_batch_dataset, get_dataset, convert_tokens, evaluate
from model import Model
import codecs

def train(config):

    with codecs.open(config.word_emb_file, "r", encoding="utf-8") as fh:
        word_mat = np.array(json.load(fh), dtype=np.float32)

    with codecs.open(config.train_eval_file, "r", encoding="utf-8") as fh:
        train_eval_file = json.load(fh)
    with codecs.open(config.dev_eval_file, "r", encoding="utf-8") as fh:
        dev_eval_file = json.load(fh)
    with codecs.open(config.dev_meta, "r") as fh:
        meta = json.load(fh)

    dev_total = meta["total"]

    print("Building model ...")
    parser = get_record_parser(config)
    train_dataset = get_batch_dataset(config.train_record_file, parser, config)
    dev_dataset = get_batch_dataset(config.dev_record_file, parser, config)
    handle = tf.placeholder(tf.string, shape=[])
    iterator = tf.data.Iterator.from_string_handle(
        handle, train_dataset.output_types, train_dataset.output_shapes
    )
    train_iterator = train_dataset.make_one_shot_iterator()
    dev_iterator = dev_dataset.make_one_shot_iterator()

    model = Model(config, iterator, word_mat)

    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True
    loss_save = 100.0
    best_acc = 0.0
    patience = 0.0
    lr = config.init_lr
    with tf.Session(config=sess_config) as sess:
        sess.run(tf.global_variables_initializer())
        writer = tf.summary.FileWriter(config.log_dir)
        saver = tf.train.Saver()
        train_handle = sess.run(train_iterator.string_handle())
        dev_handle = sess.run(dev_iterator.string_handle())
        sess.run(tf.assign(model.is_train, tf.constant(True, dtype=tf.bool)))
        sess.run(tf.assign(model.lr, tf.constant(lr, dtype=tf.float32)))

        for _ in tqdm(range(1, config.num_steps + 1)):
            global_step = sess.run(model.global_step) + 1
            loss, train_op = sess.run([model.loss, model.train_op], feed_dict={
                handle: train_handle})
            if global_step % config.period == 0:
                loss_sum = tf.Summary(value=[tf.Summary.Value(
                    tag="model/loss", simple_value=loss), ])
                writer.add_summary(loss_sum, global_step)
            if global_step % config.checkpoint == 0:
                sess.run(tf.assign(model.is_train,
                                   tf.constant(False, dtype=tf.bool)))
                _, summ = evaluate_batch(
                    model, config.val_num_batches, train_eval_file, sess, "train", handle, train_handle)
                for s in summ:
                    writer.add_summary(s, global_step)

                metrics, summ = evaluate_batch(
                    model, dev_total // config.batch_size + 1, dev_eval_file, sess, "dev", handle, dev_handle)
                sess.run(tf.assign(model.is_train,
                                   tf.constant(True, dtype=tf.bool)))

                dev_loss = metrics["loss"]
                if dev_loss < loss_save:
                    loss_save = dev_loss
                    patience = 0
                else:
                    patience += 1
                if patience >= config.patience:

                    lr /= 2.0
                    loss_save = dev_loss
                    patience = 0
                sess.run(tf.assign(model.lr, tf.constant(lr, dtype=tf.float32)))
                for s in summ:
                    writer.add_summary(s, global_step)
                writer.flush()
                filename = os.path.join(
                    config.save_dir, "model_{}.ckpt".format(global_step))
                saver.save(sess, filename)


def evaluate_batch(model, num_batches, eval_file, sess, data_type, handle, str_handle):
    answer_dict = {}
    losses = []
    for _ in tqdm(range(1, num_batches + 1)):
        qa_id, loss, yp = sess.run(
            [model.qa_id, model.loss, model.yp], feed_dict={handle: str_handle})
        answer_dict_, _ = convert_tokens(
            eval_file, qa_id.tolist(), yp)
        answer_dict.update(answer_dict_)
        losses.append(loss)
    loss = np.mean(losses)
    metrics = evaluate(answer_dict)
    metrics["loss"] = loss
    loss_sum = tf.Summary(value=[tf.Summary.Value(
        tag="{}/loss".format(data_type), simple_value=metrics["loss"]), ])
    acc_sum = tf.Summary(value=[tf.Summary.Value(
        tag="{}/acc".format(data_type), simple_value=metrics["acc"]), ])

    return metrics, [loss_sum, acc_sum]


def test(config):
    with codecs.open(config.word_emb_file, "r", encoding="utf-8") as fh:
        word_mat = np.array(json.load(fh), dtype=np.float32)
    with codecs.open(config.test_eval_file, "r", encoding="utf-8") as fh:
        eval_file = json.load(fh)
    with codecs.open(config.test_meta, "r", encoding="utf-8") as fh:
        meta = json.load(fh)
    # with open(config.char_emb_file, "r") as fh:
    #     char_mat = np.array(json.load(fh), dtype=np.float32)

    total = meta["total"]

    print("Loading model...")
    test_batch = get_dataset(config.test_record_file, get_record_parser(
        config, is_test=True), config).make_one_shot_iterator()

    # model = Model(config, test_batch, word_mat,char_mat, trainable=False)
    model = Model(config, test_batch, word_mat,False)

    sess_config = tf.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True

    with tf.Session(config=sess_config) as sess:
        sess.run(tf.global_variables_initializer())
        saver = tf.train.Saver()
        saver.restore(sess, tf.train.latest_checkpoint(config.save_dir))
        sess.run(tf.assign(model.is_train, tf.constant(False, dtype=tf.bool)))
        answer_dict = {}
        remapped_dict = {}
        for step in tqdm(range(total // config.batch_size + 1)):
            qa_id, loss, yp = sess.run(
                [model.qa_id, model.loss, model.yp])
            remapped_dict_, answer_dict_ = convert_tokens(
                eval_file, qa_id.tolist(), yp.tolist())
            answer_dict.update(answer_dict_)
            remapped_dict.update(remapped_dict_)
        with codecs.open(config.answer_file, "w", encoding="utf-8") as fh:
            for key in answer_dict:
                fh.write(str(key)+"\t"+answer_dict[key]+"\n")

        print("test")
            # json.dump(remapped_dict, fh)
