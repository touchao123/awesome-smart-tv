# ai_challenge_2018_mrc

# run
./start.sh

# idea

- slqa + attention output layer

# refer

- slqa [http://www.aclweb.org/anthology/P18-1158]
- R-net tf [https://github.com/HKUST-KnowComp/R-Net] 
- SLQA pytorch [https://github.com/SparkJiao/SLQA]
